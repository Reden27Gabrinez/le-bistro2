-- mysqldump-php https://github.com/ifsnop/mysqldump-php
--
-- Host: localhost	Database: pnp_db
-- ------------------------------------------------------
-- Server version 	5.5.5-10.4.6-MariaDB
-- Date: Tue, 19 Oct 2021 04:24:05 +0200

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40101 SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `administrator`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `administrator` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Username` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Phone` varchar(255) NOT NULL,
  `Address` varchar(255) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `administrator`
--

LOCK TABLES `administrator` WRITE;
/*!40000 ALTER TABLE `administrator` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `administrator` VALUES (1,'Reden Gabrinez','redgabrinez@gmail.com','admin','21232f297a57a5a743894a0e4a801fc3','09632357966','Purok-3, Lumipac, Baliangao, Misamis Occidental');
/*!40000 ALTER TABLE `administrator` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `administrator` with 1 row(s)
--

--
-- Table structure for table `announcements`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `announcements` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `_What` varchar(55) NOT NULL,
  `_When` varchar(55) NOT NULL,
  `_Where` varchar(55) NOT NULL,
  `CreatedAt` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `announcements` VALUES (9,'Covid Bakuna','Dec. 2, 2021','Baliangao','2021-08-30 11:34:56'),(10,'Operation Tuli','Nov. 01, 2021','Mobod','2021-08-30 11:43:38'),(13,'Blood Donations','Dec. 27, 2021','Mobod','2021-10-04 13:43:33');
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `announcements` with 3 row(s)
--

--
-- Table structure for table `articles`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `articles` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Title` varchar(255) NOT NULL,
  `Category` varchar(50) NOT NULL,
  `Image` varchar(255) NOT NULL,
  `Description` varchar(255) NOT NULL,
  `Status` varchar(5) NOT NULL,
  `Content` longtext NOT NULL,
  `Views` varchar(255) NOT NULL,
  `CreatedAt` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`Id`) USING BTREE,
  KEY `Category` (`Category`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `articles`
--

LOCK TABLES `articles` WRITE;
/*!40000 ALTER TABLE `articles` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `articles` VALUES (16,'Bloodletting Activity at Red Cross at Oroquieta City','New','uploads/red_cross.jpg','FM and Philippine Red Cross of Oroquieta City held at City Gym, Poblacion II, Oroquieta City.','1','<p>&nbsp;</p>\r\n\r\n<div style=\"page-break-after:always\"><span style=\"display:none\">&nbsp;</span></div>\r\n\r\n<hr />\r\n<p><span style=\"font-size:24px\"><span style=\"font-family:Courier New,Courier,monospace\"><sup><s><strong>On April 10</strong></s></sup>, 2021</span></span> at 9:38 AM, Personnel of Oroquieta CPS under the direct supervision of <span style=\"background-color:#f1c40f\">PLTCOL MELFIN IAN U BURLAT</span>, Officer in-charge participated the Bloodletting activity initiated by Brigada News</p>\r\n\r\n<hr />\r\n<p>dgdgfdg&nbsp;</p>\r\n\r\n<hr />\r\n<hr />\r\n<p><img alt=\"\" src=\"C:\\Users\\denden\\Desktop\\prototype\\assets\\Abract01.png\" />FM and Philippine Red Cross of Oroquieta City held at City Gym, Poblacion II, <a href=\"http://oroquieta.com\" target=\"_blank\">Oroquieta City</a>.</p>\r\n','6','2021-09-03 09:25:02'),(17,'No to PTC of NPA','Events|Activities','uploads/noto.jpg','The Commission on Election(Comelec) warned candidates not to give in to demands from the Communist Party of the Philippines.','1','<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p style=\"text-align:center\"><span style=\"font-size:28px\"><span style=\"font-family:Courier New,Courier,monospace\"><strong>The <a href=\"http://www.comelec.gov.ph\">Commission on Election(Comelec)</a></strong></span></span></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><span style=\"font-family:Courier New,Courier,monospace\">The Commission on Election(Comelec) warned candidates not to give in to demands from the Communist Party of the Philippines. New People&#39;s Army(CPP-NPA) for permit-to-campaign(PTC) fees in relation to the May 14 Barangay, Sangguniang Kabataan Elections.</span></p>\r\n\r\n<p><span style=\"font-family:Courier New,Courier,monospace\">&nbsp;This is the list of ban on Election</span></p>\r\n\r\n<ol>\r\n	<li><span style=\"font-family:Courier New,Courier,monospace\">Gun Ban</span></li>\r\n	<li><span style=\"font-family:Courier New,Courier,monospace\">No Alcohol 20 meters in Voting</span></li>\r\n	<li><span style=\"font-family:Courier New,Courier,monospace\">No Cigarette</span></li>\r\n	<li>No Campaign</li>\r\n	<li>&nbsp;</li>\r\n</ol>\r\n','5','2021-09-09 22:09:15'),(23,'Rektang Konek Aksyon Agad','New','uploads/1.jpg','On October 5, 2021 at 2:48 PM, PSSg Delia C Cabrales, CCADS PNCO of Oroquieta CPS under the direct supervision of PLTCOL MELFIN IAN U BURLAT, Officer In-Charge watched and shared at Official FB Page account the Rektang Konek Aksyon Agad.','1','<p style=\"text-align:center\">&nbsp;</p>\r\n\r\n<p style=\"text-align:center\">&nbsp;</p>\r\n\r\n<p style=\"text-align:center\"><span style=\"font-size:22px\"><span style=\"font-family:Comic Sans MS,cursive\"><strong>Rektang Konek Aksyon Agad</strong></span></span></p>\r\n\r\n<p>On October 5, 2021 at 2:48 PM, PSSg Delia C Cabrales, CCADS PNCO of Oroquieta CPS under the direct supervision of PLTCOL MELFIN IAN U BURLAT, Officer In-Charge watched and shared at Official FB Page account the Rektang Konek Aksyon Agad.</p>\r\n\r\n<p><img alt=\"\" src=\"administrator/upload/457317789.jpg\" style=\"height:250px; width:250px\" />On October 5, 2021 at 2:48 PM, PSSg Delia C Cabrales, CCADS PNCO of Oroquieta CPS under the direct supervision of PLTCOL MELFIN IAN U BURLAT, Officer In-Charge watched and shared at Official FB Page account the Rektang Konek Aksyon Agad.</p>\r\n\r\n<p>On October 5, 2021 at 2:48 PM, PSSg Delia C Cabrales, CCADS PNCO of Oroquieta CPS under the direct supervision of PLTCOL MELFIN IAN U BURLAT, Officer In-Charge watched and shared at Official <a href=\"http://facebook.com/pnp\" target=\"_blank\">FB Page</a> account the Rektang Konek Aksyon Agad.</p>\r\n\r\n<p><img alt=\"\" src=\"administrator/upload/37574614.jpg\" style=\"border-style:solid; border-width:1px; float:right; height:250px; margin:1px; width:250px\" /></p>\r\n\r\n<p>On October 5, 2021 at 2:48 PM, PSSg Delia C Cabrales, CCADS PNCO of Oroquieta CPS under the direct supervision of PLTCOL MELFIN IAN U BURLAT, Officer In-Charge watched and shared at Official FB Page account the Rektang Konek Aksyon Agad.</p>\r\n\r\n<p>On October 5, 2021 at 2:48 PM, PSSg Delia C Cabrales, CCADS PNCO of Oroquieta CPS under the direct supervision of PLTCOL MELFIN IAN U BURLAT, Officer In-Charge watched and shared at Official FB Page account the Rektang Konek Aksyon Agad.</p>\r\n','19','2021-10-06 13:08:14');
/*!40000 ALTER TABLE `articles` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `articles` with 3 row(s)
--

--
-- Table structure for table `backgroundimage`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backgroundimage` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `BackgroundImage` longtext NOT NULL,
  `Status` varchar(5) NOT NULL,
  `CreatedAt` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backgroundimage`
--

LOCK TABLES `backgroundimage` WRITE;
/*!40000 ALTER TABLE `backgroundimage` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `backgroundimage` VALUES (23,'upload/BackgroundImage/20190814_093639.jpg','1','2021-09-16 04:23:59'),(25,'upload/BackgroundImage/FB_IMG_16057742173335388.jpg','1','2021-09-29 06:50:51'),(27,'upload/BackgroundImage/IMG20200718134251.jpg','1','2021-09-29 07:05:31');
/*!40000 ALTER TABLE `backgroundimage` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `backgroundimage` with 3 row(s)
--

--
-- Table structure for table `category`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `CategoryName` varchar(50) NOT NULL,
  `Description` longtext NOT NULL,
  `CreatedAt` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`Id`,`CategoryName`) USING BTREE,
  UNIQUE KEY `CategoryName` (`CategoryName`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `category` VALUES (12,'New','latest and old news','2021-08-30 00:46:05'),(18,'Events|Activities','N/A','2021-09-03 09:22:58');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `category` with 2 row(s)
--

--
-- Table structure for table `logs`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logs` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `User` varchar(255) NOT NULL,
  `Purpose` varchar(255) NOT NULL,
  `LogsDate` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=193 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logs`
--

LOCK TABLES `logs` WRITE;
/*!40000 ALTER TABLE `logs` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `logs` VALUES (66,'Reden Gabrinez','Article Removed','2021-10-15 10:25:32'),(67,'Reden Gabrinez','admin | Logout','2021-10-15 10:44:12'),(68,'',' | Logout','2021-10-16 02:26:10'),(69,'',' | Logout','2021-10-16 02:26:50'),(70,'',' | Logout','2021-10-16 02:27:10'),(71,'',' | Logout','2021-10-16 02:27:26'),(72,'',' | Logout','2021-10-16 02:27:43'),(73,'Reden Gabrinez','admin | Login','2021-10-16 02:27:51'),(74,'Reden Gabrinez','admin | Logout','2021-10-16 02:28:23'),(75,'',' | Logout','2021-10-16 02:28:28'),(76,'',' | Logout','2021-10-16 02:28:45'),(77,'',' | Logout','2021-10-16 02:28:46'),(78,'Reden Gabrinez','admin | Login','2021-10-16 02:36:16'),(79,'Reden Gabrinez','admin | Logout','2021-10-16 02:43:26'),(80,'Reden Gabrinez','admin | Login','2021-10-16 02:43:33'),(81,'Reden Gabrinez','admin | Logout','2021-10-16 02:43:57'),(82,'',' | Logout','2021-10-16 02:45:21'),(83,'',' | Logout','2021-10-16 02:45:40'),(84,'Reden Gabrinez','admin | Login','2021-10-16 02:45:44'),(85,'','admin | Logout','2021-10-16 02:56:39'),(86,'Reden Gabrinez','admin | Login','2021-10-16 02:56:45'),(87,'Reden Gabrinez','admin | Logout','2021-10-16 02:56:54'),(88,'Reden Gabrinez','admin | Login','2021-10-16 02:57:01'),(89,'Reden Gabrinez','admin | Logout','2021-10-16 03:00:32'),(90,'Reden Gabrinez','admin | Login','2021-10-16 03:00:36'),(91,'Reden Gabrinez','admin | Logout','2021-10-16 03:01:07'),(92,'Reden Gabrinez','admin | Login','2021-10-16 03:01:17'),(93,'Reden Gabrinez','Reports Removed','2021-10-16 03:01:55'),(94,'Reden Gabrinez','admin | Logout','2021-10-16 03:02:18'),(95,'Reden Gabrinez','admin | Login','2021-10-16 03:02:22'),(96,'Reden Gabrinez','admin | Logout','2021-10-16 03:10:44'),(97,'Reden Gabrinez','admin | Login','2021-10-16 03:10:48'),(98,'Reden Gabrinez','admin | Logout','2021-10-16 03:12:00'),(99,'Reden Gabrinez','admin | Login','2021-10-16 03:12:05'),(100,'Reden Gabrinez','admin | Logout','2021-10-16 03:15:20'),(101,'',' | Logout','2021-10-17 02:22:19'),(102,'Reden Gabrinez','admin | Login','2021-10-17 02:22:28'),(103,'',' | Logout','2021-10-17 08:00:32'),(104,'Reden Gabrinez','admin | Login','2021-10-17 08:00:45'),(105,'Reden Gabrinez','admin | Logout','2021-10-17 08:01:08'),(106,'Reden Gabrinez','admin | Login','2021-10-17 08:01:15'),(107,'Reden Gabrinez','admin | Logout','2021-10-17 08:01:30'),(108,'',' | Logout','2021-10-17 08:01:46'),(109,'Reden Gabrinez','admin | Login','2021-10-17 08:01:53'),(110,'Reden Gabrinez','admin | Logout','2021-10-17 08:04:41'),(111,'Reden Gabrinez','admin | Login','2021-10-17 08:04:49'),(112,'Reden Gabrinez','admin | Logout','2021-10-17 08:05:00'),(113,'',' | Logout','2021-10-17 08:06:05'),(114,'Reden Gabrinez','admin | Login','2021-10-17 08:06:23'),(115,'Reden Gabrinez','admin | Logout','2021-10-17 08:09:14'),(116,'Reden Gabrinez','admin | Login','2021-10-17 08:09:19'),(117,'',' | Logout','2021-10-17 08:09:45'),(118,'Reden Gabrinez','admin | Login','2021-10-17 08:10:03'),(119,'Reden Gabrinez','admin | Logout','2021-10-17 08:13:36'),(120,'',' | Logout','2021-10-18 00:45:09'),(121,'Reden Gabrinez','admin | Login','2021-10-18 00:45:20'),(122,'Reden Gabrinez','admin | Logout','2021-10-18 00:54:37'),(123,'Reden Gabrinez','admin | Login','2021-10-18 00:54:42'),(124,'',' | Logout','2021-10-18 01:03:39'),(125,'',' | Logout','2021-10-18 01:04:12'),(126,'Reden Gabrinez','admin | Login','2021-10-18 01:04:16'),(127,'Reden Gabrinez','admin | Logout','2021-10-18 01:06:31'),(128,'Reden Gabrinez','admin | Login','2021-10-18 01:10:36'),(129,'Reden Gabrinez','admin | Logout','2021-10-18 01:10:44'),(130,'Reden Gabrinez','admin | Login','2021-10-18 01:11:28'),(131,'Reden Gabrinez','admin | Logout','2021-10-18 01:12:06'),(132,'Reden Gabrinez','admin | Login','2021-10-18 01:14:30'),(133,'Reden Gabrinez','admin | Login','2021-10-18 01:15:52'),(134,'',' | Logout','2021-10-18 01:21:12'),(135,'Reden Gabrinez','admin | Login','2021-10-18 01:21:37'),(136,'Reden Gabrinez','admin | Logout','2021-10-18 01:23:35'),(137,'Reden Gabrinez','admin | Login','2021-10-18 01:30:03'),(138,'Reden Gabrinez','admin | Logout','2021-10-18 01:30:18'),(139,'Reden Gabrinez','admin | Login','2021-10-18 01:30:56'),(140,'Reden Gabrinez','admin | Logout','2021-10-18 01:31:15'),(141,'Reden Gabrinez','admin | Logout','2021-10-18 01:31:28'),(142,'Reden Gabrinez','admin | Login','2021-10-18 01:32:29'),(143,'Reden Gabrinez','admin | Logout','2021-10-18 01:34:13'),(144,'Reden Gabrinez','admin | Login','2021-10-18 01:35:04'),(145,'Reden Gabrinez','admin | Logout','2021-10-18 01:35:59'),(146,'Reden Gabrinez','admin | Login','2021-10-18 01:36:50'),(147,'Reden Gabrinez','admin | Logout','2021-10-18 01:37:12'),(148,'Reden Gabrinez','admin | Login','2021-10-18 01:40:03'),(149,'Reden Gabrinez','Reports Removed','2021-10-18 01:40:27'),(150,'Reden Gabrinez','Reports Removed','2021-10-18 01:40:48'),(151,'Reden Gabrinez','Blood Donations | Updated Announcements','2021-10-18 01:41:09'),(152,'Reden Gabrinez','Reports Removed','2021-10-18 01:41:58'),(153,'Reden Gabrinez','Reports Removed','2021-10-18 01:42:03'),(154,'Reden Gabrinez','admin | Logout','2021-10-18 02:02:35'),(155,'Reden Gabrinez','admin | Login','2021-10-18 02:05:29'),(156,'Reden Gabrinez','Category Removed','2021-10-18 03:15:59'),(157,'Reden Gabrinez','admin | Logout','2021-10-18 03:28:17'),(158,'Reden Gabrinez','admin | Login','2021-10-18 03:28:28'),(159,'Reden Gabrinez','Category Removed','2021-10-18 04:19:08'),(160,'Reden Gabrinez','admin | Logout','2021-10-18 04:19:26'),(161,'qq','Users Report a qqq','2021-10-18 06:04:29'),(162,'ddd','Users Report a dddd','2021-10-18 06:41:54'),(163,'xxx','Users Report a xxx','2021-10-18 06:42:48'),(164,'q','Users Report a ddd','2021-10-18 06:43:05'),(165,'ggg','Users Report a ggg','2021-10-18 06:47:02'),(166,'gg','Users Report a ggg','2021-10-18 06:50:10'),(167,'111','Users Report a 111','2021-10-18 07:00:50'),(168,'','Users Report a www','2021-10-18 07:01:30'),(169,'Reden Gabrinez','admin | Login','2021-10-18 07:01:42'),(170,'Reden Gabrinez','admin | Logout','2021-10-18 07:11:19'),(171,'Reden Gabrinez','admin | Login','2021-10-18 22:52:14'),(172,'Reden Gabrinez','Rektang Konek Aksyon Agad | Updated to Article','2021-10-18 22:54:54'),(173,'Reden Gabrinez','Bloodletting Activity at Red Cross at Oroquieta City | Updated to Article','2021-10-18 22:55:12'),(174,'Reden Gabrinez','New | Updated to Category','2021-10-18 22:58:09'),(175,'Reden Gabrinez','Rektang Konek Aksyon Agad | Updated to Article','2021-10-18 22:59:18'),(176,'Reden Gabrinez','Bloodletting Activity at Red Cross at Oroquieta City | Updated to Article','2021-10-18 22:59:28'),(177,'Reden Gabrinez','Reden Gabrinez | Admin Profile Updated','2021-10-18 23:02:10'),(178,'Reden Gabrinez','No to PTC of NPA | Updated to Article','2021-10-18 23:03:52'),(179,'Reden Gabrinez','No to PTC of NPA | Updated to Article','2021-10-18 23:06:01'),(180,'Reden Gabrinez','No to PTC of NPA | Updated to Article','2021-10-18 23:07:31'),(181,'Reden Gabrinez','No to PTC of NPA | Updated to Article','2021-10-18 23:09:31'),(182,'Reden Gabrinez','No to PTC of NPA | Updated to Article','2021-10-18 23:10:11'),(183,'ww','Users Report a www','2021-10-18 23:11:23'),(184,'Reden Gabrinez','admin | Logout','2021-10-18 23:15:16'),(185,'Reden Gabrinez','admin | Login','2021-10-18 23:15:50'),(186,'Reden Gabrinez','admin | Logout','2021-10-18 23:15:56'),(187,'Reden Gabrinez','admin | Login','2021-10-18 23:17:31'),(188,'Reden Gabrinez','admin | Logout','2021-10-18 23:19:04'),(189,'Reden Gabrinez','admin | Login','2021-10-18 23:19:11'),(190,'Reden Gabrinez','admin | Logout','2021-10-18 23:21:58'),(191,'red','Users Report a red','2021-10-19 01:32:16'),(192,'Reden Gabrinez','admin | Login','2021-10-19 01:43:30');
/*!40000 ALTER TABLE `logs` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `logs` with 127 row(s)
--

--
-- Table structure for table `reports`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reports` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `WhatHappen` longtext NOT NULL,
  `WheredidHappen` varchar(255) NOT NULL,
  `WhendidHappen` varchar(255) NOT NULL,
  `Incident` varchar(255) NOT NULL,
  `Reporter` varchar(2555) NOT NULL,
  `CreatedAt` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reports`
--

LOCK TABLES `reports` WRITE;
/*!40000 ALTER TABLE `reports` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `reports` VALUES (5,'patay ','mobod','sa dec','Murder','fdf','2021-10-07 08:19:25'),(6,'sunog','mobod','September 2, 2021','Arson','red','2021-10-07 08:25:51'),(8,'rrrrrr','rrrrrrrrrrr','rrrrrrrrrrrr','rrrrrrrrrrr','rrrrrrrrrrr','2021-10-07 08:35:28'),(9,'gggg','ggg','ggg','gg','','2021-10-07 08:40:21'),(16,'qqq','qq','qq','qq','qq','2021-10-18 06:04:29'),(17,'dddd','ddd','ddd','ddd','ddd','2021-10-18 06:41:54'),(18,'xxx','xxx','xxx','xx','xxx','2021-10-18 06:42:48'),(19,'ddd','dd','qqq','fdfdq','q','2021-10-18 06:43:05'),(20,'ggg','ggg','ggg','ggg','ggg','2021-10-18 06:47:02'),(21,'ggg','gg','gg','gg','gg','2021-10-18 06:50:10'),(22,'111','1111','1111','111','111','2021-10-18 07:00:50'),(23,'www','www','www','ww','','2021-10-18 07:01:30'),(24,'www','ww','ww','ww','ww','2021-10-18 23:11:23'),(25,'red','red','red','red','red','2021-10-19 01:32:16');
/*!40000 ALTER TABLE `reports` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `reports` with 14 row(s)
--

/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;
/*!40101 SET AUTOCOMMIT=@OLD_AUTOCOMMIT */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on: Tue, 19 Oct 2021 04:24:05 +0200
