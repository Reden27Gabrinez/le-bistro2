-- mysqldump-php https://github.com/ifsnop/mysqldump-php
--
-- Host: localhost	Database: pnp_db
-- ------------------------------------------------------
-- Server version 	5.5.5-10.4.6-MariaDB
-- Date: Tue, 12 Oct 2021 12:50:39 +0200

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40101 SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `administrator`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `administrator` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Username` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Phone` varchar(255) NOT NULL,
  `Address` varchar(255) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `administrator`
--

LOCK TABLES `administrator` WRITE;
/*!40000 ALTER TABLE `administrator` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `administrator` VALUES (1,'AngTarEmGabz','redgabrinez@gmail.com','admin','21232f297a57a5a743894a0e4a801fc3','09632357966','Mobod,Oroquieta City, Misamis Occidental');
/*!40000 ALTER TABLE `administrator` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `administrator` with 1 row(s)
--

--
-- Table structure for table `announcements`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `announcements` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `_What` varchar(55) NOT NULL,
  `_When` varchar(55) NOT NULL,
  `_Where` varchar(55) NOT NULL,
  `CreatedAt` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `announcements` VALUES (9,'Covid Bakuna fsdfsd sdfsdf sdf sdfsdf','mayhahah','dasdsa','2021-08-30 11:34:56'),(10,'Operation Tuli','Nov. 01, 2021','Mobod','2021-08-30 11:43:38'),(13,'Blood Donation','Dec. 27, 2021','Mobod','2021-10-04 13:43:33');
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `announcements` with 3 row(s)
--

--
-- Table structure for table `articles`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `articles` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Title` varchar(255) NOT NULL,
  `Category` varchar(50) NOT NULL,
  `Image` varchar(255) NOT NULL,
  `Description` varchar(255) NOT NULL,
  `Status` varchar(5) NOT NULL,
  `Content` longtext NOT NULL,
  `Views` varchar(255) NOT NULL,
  `CreatedAt` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`Id`) USING BTREE,
  KEY `Category` (`Category`),
  CONSTRAINT `articles_ibfk_1` FOREIGN KEY (`Category`) REFERENCES `category` (`CategoryName`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `articles`
--

LOCK TABLES `articles` WRITE;
/*!40000 ALTER TABLE `articles` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `articles` VALUES (15,'NPA Condemnation No to CPP-NPA','Case-Updates','uploads/npa_condem.jpg','Mariing kinokondena ng Pambansang Kapulisan and recruitment ng mga estudyante at kabataan.','1','<p><span style=\"background-color:#2ecc71\">Mariing kinokon</span>dena ng<span class=\"marker\"><span style=\"background-color:#f1c40f\"> <a href=\"http://fb.com/reden.gabrinez\" target=\"_blank\">Pambansang Kapulisan</a></span></span> and recruitmen<span style=\"color:#f1c40f\">t ng mga estudyante </span>at kabataan.</p>\r\n','5','2021-09-03 09:15:02'),(16,'Bloodletting Activity at Red Cross at Oroquieta City','Events|Activities','uploads/red_cross.jpg','FM and Philippine Red Cross of Oroquieta City held at City Gym, Poblacion II, Oroquieta City.','1','<p>&nbsp;</p>\r\n\r\n<div style=\"page-break-after:always\"><span style=\"display:none\">&nbsp;</span></div>\r\n\r\n<hr />\r\n<p><span style=\"font-size:24px\"><span style=\"font-family:Courier New,Courier,monospace\"><sup><s><strong>On April 10</strong></s></sup>, 2021</span></span> at 9:38 AM, Personnel of Oroquieta CPS under the direct supervision of <span style=\"background-color:#f1c40f\">PLTCOL MELFIN IAN U BURLAT</span>, Officer in-charge participated the Bloodletting activity initiated by Brigada News</p>\r\n\r\n<hr />\r\n<p>dgdgfdg&nbsp;</p>\r\n\r\n<hr />\r\n<hr />\r\n<p><img alt=\"\" src=\"C:\\Users\\denden\\Desktop\\prototype\\assets\\Abract01.png\" />FM and Philippine Red Cross of Oroquieta City held at City Gym, Poblacion II, <a href=\"http://oroquieta.com\" target=\"_blank\">Oroquieta City</a>.</p>\r\n','5','2021-09-03 09:25:02'),(17,'No to PTC of NPA','News','uploads/noto.jpg','0','0','<p><kbd><span style=\"font-size:14px\">The Commission on Election(Comelec) warned candidates not to give in to demands from the Communist Party of the Philippines. New People&#39;s Army(CPP-NPA) for permit-to-campaign(PTC) fees in relation to the May 14 Barangay, Sangguniang Kabataan Elections.</span></kbd></p>\r\n\r\n<p><kbd>&nbsp;</kbd></p>\r\n','','2021-09-09 22:09:15'),(18,'gus','Case-Updates','uploads/MLBB (Mobile Legends).jpg','0','0','<p><img alt=\"\" src=\"ckeditor/uploads/noto.jpg\" />fsdfsfsfsfsfsfffffffffffffffffffffffffffffffffffffffffffffffffff<img alt=\"\" src=\"ckeditor/uploads/MLBB Wallpaper HD-4K - Gusion (1).jpg\" style=\"float:left; width:120px\" /><img alt=\"\" src=\"ckeditor/uploads/MLBB (Mobile Legends).jpg\" style=\"float:right; width:120px\" /></p>\r\n','','2021-09-10 23:13:52'),(19,'ffff','Case-Updates','uploads/MLBB Wallpaper HD-4K - Gusion.jpg','tjrl  lsgjsltjlkw jlksj krjtkl sjfklej lkewjk jlskjlk lkdsjgeljgldg ljsdfkgljerk ljkldjgdlgjrle jdkfgjler jg;g jdl rjldfbj lrdjfgldfglr jfdg;se jrgdjflkgjl jre;jdfglerg dfjgslg ;jertjkrj lfj glsjlrl lgj grgjlsdg ej lfgsjg;rjgl sjl gerg ljjrtlkj lkbks','0','<p><img alt=\"\" src=\"administrator/upload/504714589.jpg\" style=\"height:414px; width:735px\" />&nbsp;&nbsp;&nbsp;&nbsp;</p>\r\n\r\n<p>f</p>\r\n\r\n<p>ilebrowserUploadMethod:&nbsp;&quot;form&quot;</p>\r\n\r\n<p><img alt=\"\" src=\"administrator/upload/231522379.jpg\" style=\"height:311px; width:175px\" /></p>\r\n','','2021-09-10 23:46:05'),(20,'MLBB','Covid-Update','uploads/MLBB (Mobile Legends).jpg','ndimentum at, ultrices a, luctus ut, orci. Donec pellentesque egestas eros. Integer cursus, augue in cursus faucibus, eros pede bibendum sem, in tempus tellus justo quis ligula. Etiam eget tortor. Vestibulum rutrum, est ut placerat elementum, lectus ','1','<p>&nbsp;</p>\r\n\r\n<ol>\r\n	<li>&nbsp;</li>\r\n	<li>&nbsp;</li>\r\n	<li>&nbsp;</li>\r\n	<li>&nbsp;</li>\r\n	<li>&nbsp;</li>\r\n	<li>&nbsp;</li>\r\n	<li>&nbsp;</li>\r\n	<li>&nbsp;</li>\r\n	<li>&nbsp;</li>\r\n	<li>&nbsp;</li>\r\n	<li>&nbsp;</li>\r\n	<li>&nbsp;</li>\r\n	<li>&nbsp;</li>\r\n	<li>&nbsp;</li>\r\n	<li>&nbsp;</li>\r\n	<li>&nbsp;</li>\r\n	<li>&nbsp;</li>\r\n</ol>\r\n\r\n<table style=\"background-color:#e6e6fa; border-style:hidden\">\r\n	<tbody>\r\n		<tr>\r\n			<td>\r\n			<p><img alt=\"\" src=\"administrator/upload/1161138511.jpg\" style=\"border-style:solid; border-width:3px; float:left; height:301px; margin:1px 5px; width:164px\" />Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas feugiat consequat diam. Maecenas metus. Vivamus diam purus, cursus a, commodo non, facilisis vitae, nulla. Aenean dictum lacinia tortor. Nunc iaculis, nibh non iaculis aliquam, orci felis euismod neque, sed ornare massa mauris sed velit. Nulla pretium mi et risus. Fusce mi pede, tempor id, cursus ac, ullamcorper nec, enim. Sed tortor. Curabitur molestie. Duis velit augue, condimentum at, ultrices a, luctus ut, orci. Donec pellentesque egestas eros. Integer cursus, augue in cursus faucibus, eros pede bibendum sem, in tempus tellus justo quis ligula. Etiam eget tortor. Vestibulum rutrum, est ut placerat elementum, lectus nisl aliquam velit, tempor aliquam eros nunc nonummy metus. In eros metus, gravida a, gravida sed, lobortis id, turpis. Ut ultrices, ipsum at venenatis fringilla, sem nulla lacinia tellus, eget aliquet turpis mauris non enim. Nam turpis. Suspendisse lacinia. Curabitur ac tortor ut ipsum egestas elementum. Nunc imperdiet gravida mauris.</p>\r\n\r\n			<p><img alt=\"\" src=\"administrator/upload/400341707.jpg\" style=\"border-style:solid; border-width:2px; float:right; height:414px; margin:2px; width:235px\" /></p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<table align=\"center\" border=\"1\" cellspacing=\"1\" style=\"width:500px\" summary=\"oks\">\r\n	<caption>haha</caption>\r\n	<thead>\r\n		<tr>\r\n			<th scope=\"col\">&nbsp;Code</th>\r\n			<th scope=\"col\">Program</th>\r\n			<th scope=\"col\">Description</th>\r\n		</tr>\r\n	</thead>\r\n	<tbody>\r\n		<tr>\r\n			<td>IT211</td>\r\n			<td>\r\n			<p>?=&nbsp;$category;&nbsp;?&gt;</p>\r\n			</td>\r\n			<td>include_once&nbsp;(&quot;includes/carousel.php&quot;);&nbsp;?&gt;</td>\r\n		</tr>\r\n		<tr>\r\n			<td>IT-212</td>\r\n			<td>?=&nbsp;$category;&nbsp;?&gt;<!--?=Â $title;Â ?--></td>\r\n			<td>include_once&nbsp;(&quot;includes/carousel.php&quot;);&nbsp;?&gt;</td>\r\n		</tr>\r\n		<tr>\r\n			<td>IT-213</td>\r\n			<td>?=&nbsp;$category;&nbsp;?&gt;\r\n			<p><!--?=Â $content;Â ?--></p>\r\n			</td>\r\n			<td>include_once&nbsp;(&quot;includes/carousel.php&quot;);&nbsp;?&gt;</td>\r\n		</tr>\r\n		<tr>\r\n			<td>IT-214</td>\r\n			<td>?=&nbsp;$category;&nbsp;?&gt;\r\n			<p><!--?=Â $content;Â ?--></p>\r\n			</td>\r\n			<td>include_once&nbsp;(&quot;includes/carousel.php&quot;);&nbsp;?&gt;</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n','6','2021-09-11 00:09:31'),(21,'qqqqqq','Case-Updates','uploads/MLBB Wallpaper HD-4K - Gusion.jpg','Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas feugiat consequat diam. Maecenas metus. Vivamus diam purus, cursus a, commodo non, facilisis vitae, nulla. Aenean dictum lacinia tortor. Nunc iaculis, nibh non iaculis aliquam, orci f','0','<p><!--?phpÂ include_onceÂ (\"includes/swiper.php\");Â ?--></p>\r\n\r\n<h1 style=\"text-align:center\"><span style=\"font-family:Comic Sans MS,cursive\"><span style=\"font-size:26px\">Lorem ipsum dolor sit amet, consectetuer adipiscing</span></span></h1>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<table>\r\n	<tbody>\r\n		<tr>\r\n			<td>\r\n			<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas feugiat consequat diam. Maecenas metus. Vivamus diam purus, cursus a, commodo non, facilisis vitae, nulla. Aene<img alt=\"\" src=\"administrator/upload/1541560420.jpg\" style=\"border-style:solid; border-width:3px; float:left; height:214px; margin:3px; width:235px\" />an dictum lacinia tortor. Nunc iaculis, nibh non iaculis aliquam, orci felis euismod neque, sed ornare massa mauris sed velit. Nulla pretium mi et risus. Fusce mi pede, tempor id, cursus ac, ullamcorper nec, enim. Sed tortor. Curabitur molestie. Duis velit augue, condimentum at, ultrices a, luctus ut, orci. Donec pellentesque egestas eros. Integer cursus, augue in cursus faucibus, eros pede bibendum sem, in tempus tellus justo quis ligula. Etiam eget tortor. Vestibulum rutrum, est ut placerat elementum, lectus nisl aliquam velit, tempor aliquam eros nunc nonummy metus. In eros metus, gravida a, gravida sed, lobortis id, turpis. Ut ultrices, ipsum at venenatis fringilla, sem nulla lacinia tellus, eget aliquet turpis mauris non enim. Nam turpis. Suspendisse lacinia. Curabitur ac tortor ut ipsum egestas elementum. Nunc imperdiet gravida mauris.</p>\r\n\r\n			<p><img alt=\"yes\" src=\"http://localhost/try/capstone/pnp/administrator/assets/ckeditor/plugins/smiley/images/thumbs_up.png\" style=\"height:23px; width:23px\" title=\"yes\" /></p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;</p>\r\n\r\n<div class=\"container\">\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>\r\n\r\n<p>Article&nbsp;Posted</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>\r\n\r\n<div class=\"row\">\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>\r\n\r\n<div class=\"col-md-8\">\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<!--?php</p--></p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$query&nbsp;&nbsp;=&nbsp;&quot;SELECT&nbsp;*&nbsp;FROM&nbsp;articles&nbsp;ORDER&nbsp;BY&nbsp;rand()&quot;;</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$stmt&nbsp;&nbsp;&nbsp;=&nbsp;$conn-&gt;prepare($query);</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$stmt&nbsp;&nbsp;&nbsp;-&gt;execute();</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$result&nbsp;=&nbsp;$stmt-&gt;get_result();</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;while($row&nbsp;=&nbsp;$result-&gt;fetch_assoc())</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$timestamp&nbsp;&nbsp;=&nbsp;$row[&#39;CreatedAt&#39;];</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$date&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;=&nbsp;date(&#39;dS&nbsp;M&nbsp;Y&#39;,strtotime($timestamp));</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$time&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;=&nbsp;date(&#39;h:i&nbsp;A&#39;,strtotime($timestamp));</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;if($row[&#39;Status&#39;]&nbsp;==&nbsp;1)</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;?&gt;</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>\r\n\r\n<div class=\"mb-5\">\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>\r\n\r\n<div class=\"a bg-dark card p-2 text-white\">\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>\r\n\r\n<div class=\"div\">\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src=\"administrator &lt;?=\" />&quot;&nbsp;height=&quot;320&quot;&nbsp;alt=&quot;<!--?=Â $row[\'Title\'];Â ?-->&quot;</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;class=&quot;card-img-top&nbsp;animate__animated&nbsp;wow&nbsp;animate__rotateInUpRight&nbsp;article-img&quot;&gt;</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n\r\n<p><cite><!--?phpÂ echoÂ $date;Â ?-->&nbsp;At&nbsp;<!--?phpÂ echoÂ $time;Â ?--> </cite></p>\r\n\r\n<p><cite>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</cite></p>\r\n\r\n<p><cite><em>&nbsp;51&nbsp;Views</em></cite></p>\r\n','','2021-09-11 05:27:40'),(23,'Rektang Konek Aksyon Agad','Events|Activities','uploads/1.jpg','On October 5, 2021 at 2:48 PM, PSSg Delia C Cabrales, CCADS PNCO of Oroquieta CPS under the direct supervision of PLTCOL MELFIN IAN U BURLAT, Officer In-Charge watched and shared at Official FB Page account the Rektang Konek Aksyon Agad.','1','<p style=\"text-align:center\">&nbsp;</p>\r\n\r\n<p style=\"text-align:center\">&nbsp;</p>\r\n\r\n<p style=\"text-align:center\"><span style=\"font-size:22px\"><span style=\"font-family:Comic Sans MS,cursive\"><strong>Rektang Konek Aksyon Agad</strong></span></span></p>\r\n\r\n<p>On October 5, 2021 at 2:48 PM, PSSg Delia C Cabrales, CCADS PNCO of Oroquieta CPS under the direct supervision of PLTCOL MELFIN IAN U BURLAT, Officer In-Charge watched and shared at Official FB Page account the Rektang Konek Aksyon Agad.</p>\r\n\r\n<p><img alt=\"\" src=\"administrator/upload/457317789.jpg\" style=\"height:250px; width:250px\" />On October 5, 2021 at 2:48 PM, PSSg Delia C Cabrales, CCADS PNCO of Oroquieta CPS under the direct supervision of PLTCOL MELFIN IAN U BURLAT, Officer In-Charge watched and shared at Official FB Page account the Rektang Konek Aksyon Agad.</p>\r\n\r\n<p>On October 5, 2021 at 2:48 PM, PSSg Delia C Cabrales, CCADS PNCO of Oroquieta CPS under the direct supervision of PLTCOL MELFIN IAN U BURLAT, Officer In-Charge watched and shared at Official <a href=\"http://facebook.com/pnp\" target=\"_blank\">FB Page</a> account the Rektang Konek Aksyon Agad.</p>\r\n\r\n<p><img alt=\"\" src=\"administrator/upload/37574614.jpg\" style=\"border-style:solid; border-width:1px; float:right; height:250px; margin:1px; width:250px\" /></p>\r\n\r\n<p>On October 5, 2021 at 2:48 PM, PSSg Delia C Cabrales, CCADS PNCO of Oroquieta CPS under the direct supervision of PLTCOL MELFIN IAN U BURLAT, Officer In-Charge watched and shared at Official FB Page account the Rektang Konek Aksyon Agad.</p>\r\n\r\n<p>On October 5, 2021 at 2:48 PM, PSSg Delia C Cabrales, CCADS PNCO of Oroquieta CPS under the direct supervision of PLTCOL MELFIN IAN U BURLAT, Officer In-Charge watched and shared at Official FB Page account the Rektang Konek Aksyon Agad.</p>\r\n','19','2021-10-06 13:08:14'),(26,'qqq','Case-Updates','uploads/IMG20200718134251.jpg','qqq','1','<p>ddddd</p>\r\n','5','2021-10-12 03:25:34');
/*!40000 ALTER TABLE `articles` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `articles` with 9 row(s)
--

--
-- Table structure for table `backgroundimage`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backgroundimage` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `BackgroundImage` longtext NOT NULL,
  `Status` varchar(5) NOT NULL,
  `CreatedAt` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backgroundimage`
--

LOCK TABLES `backgroundimage` WRITE;
/*!40000 ALTER TABLE `backgroundimage` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `backgroundimage` VALUES (23,'upload/BackgroundImage/20190814_093639.jpg','1','2021-09-16 04:23:59'),(25,'upload/BackgroundImage/FB_IMG_16057742173335388.jpg','1','2021-09-29 06:50:51'),(27,'upload/BackgroundImage/IMG20200718134251.jpg','1','2021-09-29 07:05:31');
/*!40000 ALTER TABLE `backgroundimage` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `backgroundimage` with 3 row(s)
--

--
-- Table structure for table `category`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `CategoryName` varchar(50) NOT NULL,
  `Description` longtext NOT NULL,
  `CreatedAt` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`Id`,`CategoryName`) USING BTREE,
  UNIQUE KEY `CategoryName` (`CategoryName`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `category` VALUES (10,'Case-Updates','case updated or old case ','2021-08-30 00:45:43'),(12,'News','latest and old news','2021-08-30 00:46:05'),(18,'Events|Activities','N/A','2021-09-03 09:22:58'),(29,'Covid-Update','ddd','2021-10-10 00:04:38');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `category` with 4 row(s)
--

--
-- Table structure for table `logs`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logs` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `User` varchar(255) NOT NULL,
  `Purpose` varchar(255) NOT NULL,
  `LogsDate` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logs`
--

LOCK TABLES `logs` WRITE;
/*!40000 ALTER TABLE `logs` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `logs` VALUES (1,'admin','admin Login','2021-10-11 23:39:32'),(2,'admin','admin Login','2021-10-11 23:41:56'),(3,'admin',' Login','2021-10-11 23:56:19'),(4,'admin',' Login','2021-10-11 23:58:08'),(5,'',' Logout','2021-10-11 23:58:49'),(6,'admin',' Login','2021-10-12 00:02:16'),(7,'',' Logout','2021-10-12 00:04:12'),(8,'Administrator','admin Login','2021-10-12 00:04:25'),(9,'',' Logout','2021-10-12 00:07:39'),(10,'admin','AngTarEmGab Login','2021-10-12 00:07:52'),(11,'','AngTarEmGab Logout','2021-10-12 00:09:00'),(12,'admin','AngTarEmGab Login','2021-10-12 00:09:36'),(13,'admin','AngTarEmGab Logout','2021-10-12 00:09:42'),(14,'AngTarEmGab','admin Login','2021-10-12 00:11:09'),(15,'AngTarEmGab','admin Logout','2021-10-12 00:11:21'),(16,'AngTarEmGab','admin Login','2021-10-12 00:17:19'),(17,'AngTarEmGab','Water is added to Category','2021-10-12 00:22:34'),(18,'AngTarEmGab','45 is Deleted from Category','2021-10-12 00:26:57'),(19,'AngTarEmGab','Water is added as Category','2021-10-12 00:31:24'),(20,'AngTarEmGab','Deleted Category','2021-10-12 00:31:41'),(21,'AngTarEmGab','Case-Update Category Updated','2021-10-12 00:37:29'),(22,'AngTarEmGab','Case-Updates  Updated to Category','2021-10-12 00:38:54'),(23,'AngTarEmGab','dddd | Added as Category','2021-10-12 00:41:57'),(24,'AngTarEmGab','ddddtrtrtr | Updated to Category','2021-10-12 00:42:06'),(25,'AngTarEmGab','Category Removed','2021-10-12 00:42:10'),(26,'AngTarEmGab','ddd | Added to Announcement','2021-10-12 00:47:44'),(27,'AngTarEmGab','dddfffff | Updated Announcements','2021-10-12 00:47:59'),(28,'AngTarEmGab','Deleted Announcement','2021-10-12 00:48:04'),(29,'AngTarEmGab','eeee | Added to Article','2021-10-12 00:55:52'),(30,'AngTarEmGab','eeeetrtrtr | Updated to Article','2021-10-12 00:56:12'),(31,'AngTarEmGab','Added Removed','2021-10-12 00:57:02'),(32,'AngTarEmGab','Reports Removed','2021-10-12 01:01:26'),(33,'AngTarEmGab','AngTarEmGab2 | Admin Profile Updated','2021-10-12 01:03:19'),(34,'AngTarEmGab','AngTarEmGabz | Admin Profile Updated','2021-10-12 01:03:43'),(35,'AngTarEmGab','Admin Password Updated','2021-10-12 01:19:43'),(36,'AngTarEmGab','Admin Password Updated','2021-10-12 01:20:26'),(37,'',' | Logout','2021-10-12 02:38:28'),(38,'',' | Logout','2021-10-12 02:38:28'),(39,'AngTarEmGabz','admin | Login','2021-10-12 02:38:33'),(40,'AngTarEmGabz','admin | Logout','2021-10-12 02:38:57'),(41,'AngTarEmGabz','admin | Login','2021-10-12 02:39:01'),(42,'AngTarEmGabz','qqqqq | Added to Article','2021-10-12 03:10:25'),(43,'AngTarEmGabz','qqq | Added to Article','2021-10-12 03:25:34'),(44,'AngTarEmGabz','Article Removed','2021-10-12 03:25:43'),(45,'AngTarEmGabz','Rektang Konek Aksyon Agad | Updated to Article','2021-10-12 03:51:10'),(47,'gab','gab | Users Report a rrrr','2021-10-12 04:06:06'),(48,'ustp','ustp | Users Report a 1111','2021-10-12 04:08:24'),(49,'AngTarEmGabz','admin | Logout','2021-10-12 04:16:27'),(50,'',' | Logout','2021-10-12 09:14:46'),(51,'AngTarEmGabz','admin | Login','2021-10-12 09:15:04');
/*!40000 ALTER TABLE `logs` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `logs` with 50 row(s)
--

--
-- Table structure for table `reports`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reports` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `WhatHappen` longtext NOT NULL,
  `WheredidHappen` varchar(255) NOT NULL,
  `WhendidHappen` varchar(255) NOT NULL,
  `Incident` varchar(255) NOT NULL,
  `Reporter` varchar(2555) NOT NULL,
  `CreatedAt` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reports`
--

LOCK TABLES `reports` WRITE;
/*!40000 ALTER TABLE `reports` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `reports` VALUES (1,'fdfd','ff','fdfd','fd','fdf','2021-10-07 12:09:55'),(5,'patay ','mobod','sa dec','Murder','fdf','2021-10-07 08:19:25'),(6,'sunog','mobod','September 2, 2021','Arson','red','2021-10-07 08:25:51'),(8,'rrrrrr','rrrrrrrrrrr','rrrrrrrrrrrr','rrrrrrrrrrr','rrrrrrrrrrr','2021-10-07 08:35:28'),(9,'gggg','ggg','ggg','gg','','2021-10-07 08:40:21'),(10,'nnnn','nnn','nnn','nnn','nnn','2021-10-07 08:42:07'),(12,'fdfd','fdf','fd','fd','fd','2021-10-12 03:52:37'),(13,'ddd','ddd','vvv','vv','gab','2021-10-12 04:00:44'),(14,'rrrr','rrrr','rrrrr','Sunog','gab','2021-10-12 04:06:06'),(15,'1111','1111','1111','Holdap','ustp','2021-10-12 04:08:24');
/*!40000 ALTER TABLE `reports` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `reports` with 10 row(s)
--

/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;
/*!40101 SET AUTOCOMMIT=@OLD_AUTOCOMMIT */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on: Tue, 12 Oct 2021 12:50:39 +0200
